﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            refreshdata();
        }
    }

    public void refreshdata()
    {
        SqlConnection con = new SqlConnection(@"Data Source=Nilesh;Initial Catalog=nil_db;Integrated Security=True");
        con.Open();
        SqlCommand cmd = new SqlCommand("select * from tbl_data", con);
        SqlDataAdapter sda = new SqlDataAdapter(cmd);
        DataTable dt = new DataTable();
        sda.Fill(dt);
        GridView1.DataSource = dt;
        GridView1.DataBind();
 
   }


    protected void chckchanged(object sender, EventArgs e)
    {
        CheckBox chckheader = (CheckBox)GridView1.HeaderRow.FindControl("CheckBox1");
        foreach (GridViewRow row in GridView1.Rows)
        {
            CheckBox chckrw = (CheckBox)row.FindControl("CheckBox2");

            if (chckheader.Checked == true)
            {
                chckrw.Checked = true;
            }
            else
            {
                chckrw.Checked = false;
            }
        }
    
    }
}