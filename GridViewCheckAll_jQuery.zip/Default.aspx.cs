﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!this.IsPostBack)
        {
            DataTable dt = new DataTable();
            dt.Columns.AddRange(new DataColumn[2] { new DataColumn("Name"), new DataColumn("Country") });
            dt.Rows.Add("John Hammond", "Canada");
            dt.Rows.Add("Rick Stewards", "United States");
            dt.Rows.Add("Huang He", "China");
            dt.Rows.Add("Mudassar Khan", "India");
            GridView1.DataSource = dt;
            GridView1.DataBind();
            dt.Rows.Clear();
            dt.Rows.Add("Wills Smith", "United States");
            dt.Rows.Add("Raj Shekaran", "India");
            dt.Rows.Add("Rob Mills", "Russia");
            GridView2.DataSource = dt;
            GridView2.DataBind();
            dt.Rows.Clear();
            dt.Rows.Add("Jason Mathews", "Canada");
            dt.Rows.Add("Asim Iqbal", "UAE");
            dt.Rows.Add("Bravo Samuels", "Brazil");
            dt.Rows.Add("Walter Slater", "Mexico");
            GridView3.DataSource = dt;
            GridView3.DataBind();
        }
    }
}